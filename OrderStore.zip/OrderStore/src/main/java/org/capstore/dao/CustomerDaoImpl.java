package org.capstore.dao;

import java.util.Date;

import org.capstore.domain.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;



@Repository
public class CustomerDaoImpl implements CustomerDao {

	
	@Autowired
	private SessionFactory sessionFactory;
 @Transactional
	@Override
	public void saveCustomer(Customer customer) {
		
	 	String staticPart = "http://www.yoursite.com/foo/";

			//randomly generate the integer number and store in variable (e.g. ranNum)

			int ranNum = (int) (Math.random()*1000);
			String finalURL = staticPart + Integer.toString(ranNum);
	 
	  Session session = this.sessionFactory.getCurrentSession();
	    session.beginTransaction();
		customer.setRegdate(new Date());
		customer.setVerification_code(finalURL);
		customer.setEmail_verified(0);
		
		
		int car=(int) (Math.random()*5000);
		System.out.println(car);
		customer.setCart_id(car);
		
		
		
		
		
		
		sessionFactory.getCurrentSession().save(customer);
		session.getTransaction().commit();
	    //session.close();
		
		/*Session session=getSessionFactory().getCurrentSession();
		   Transaction trans=session.beginTransaction();
		   session.save(customer);
		   trans.commit();*/
		   
		   
		 /*  Session session = sessionFactory.openSession();
		   Transaction tx = null;
		   try {
		      tx = session.beginTransaction();


		      tx.commit(); // Flush happens automatically
		   }
		   catch (RuntimeException e) {
		      tx.rollback();
		      throw e; // or display error message
		   }
		   finally {
		       session.close();
		   }
		   */
		   
		
		
		   
		   
	}

	
	
	/*public void create(T entity) {
		   Session session=getSessionFactory().getCurrentSession();
		   Transaction trans=session.beginTransaction();
		   session.save(entity);
		   trans.commit();
		}*/

}
