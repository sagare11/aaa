package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForList implements IActorDao {

	@Override
	public List<Actor> getActors() {
		
		List<Actor> actors = new ArrayList<>();
		
		actors.add(new Actor(101, "Akshay", "Kumar"));
		actors.add(new Actor(102, "Salman", "Khan"));
		actors.add(new Actor(103, "Amir", "Khan"));
		actors.add(new Actor(104, "Shahrukh", "Khan"));
		actors.add(new Actor(105, "Ajay", "Devgan"));
		
		
		return actors;
	}

}
