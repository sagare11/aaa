function validateForm()

{

 var flag=true;
	
	
	
	var title = addfilm.filmtitle.value;
	
	var length = addfilm.filmlength.value;
	
	var cost=addfilm.replacementcost.value;
	
	var rentalDate = addfilm.rentalduration.value;
	
	var releaseyear=addfilm.releasedate.value;
	
	var letters = /^[A-Za-z0-9_ ]*$/;
	

	 
		
	if((title=="" || title==null) || !title.match(letters) )
	
	{
		
		document.getElementById("titlefilm").innerHTML="* Please enter a title";
		
		flag=false;
	}
	
	else
	 {
		document.getElementById("titlefilm").innerHTML="";
	 }
	
   if((length == ""||length == null) || length > 1000)
   
   {
		
		document.getElementById("lengthfilm").innerHTML="*Please enter a value below 1000";
		
		flag = false;
	}
   
	else
	 {
		document.getElementById("lengthfilm").innerHTML="";
	    
	 }
   
   
   if((cost==""||cost==null) || cost < 10000)
   {
		
		document.getElementById("replacementcostfms").innerHTML="*Enter Valid Replacement Cost";
		
		flag = false;
	}
		
	else
		
		{
		document.getElementById("replacementcostfms").innerHTML="";
		
		}
   
   if((rentalDate==""||rentalDate==null) || rentalDate<releaseyear)
   { 
		
		document.getElementById("rentaldurationfms").innerHTML="*RentalDate should be Greater than ReleaseDate";
		
		flag = false;
	}
		
	else
		{
		document.getElementById("rentaldurationfms").innerHTML="";
		}
   
   
   if((releaseyear==""||releaseyear==null))
   {
		
		document.getElementById("relasedate").innerHTML="*Invalid release date";
		
		flag = false;
	}
		
	else
		{
		document.getElementById("relasedate").innerHTML="";
		}
   
   
   
   
   
     
   return flag;
 
}




 
   