$(function(){

	$("#date23").datepicker({
		
		numberOfMonths:1,
			showWeek:false,
			changeMonth:true,
			changeYear:true,
			showButtonPanel:true,
			maxDate: new Date(),
			dateFormat:"dd-M-yy"
		});
		
		
	});

$(function(){

	$("#date24").datepicker({
		
		numberOfMonths:1,
			showWeek:false,
			changeMonth:true,
			changeYear:true,
			showButtonPanel:true,
			dateFormat:"dd-M-yy"
		});
		
		
	});