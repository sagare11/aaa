//Validation for film title
function istitlevalidate()  
{   
		var filmtitle=fms.filmtitle.value;
		
		var letters = /^[A-Za-z]+$/;  
		if(filmtitle.match(letters))  
		{  
			document.getElementById("titlefilm").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("titlefilm").innerHTML="*Title should only contain alphabet"; 
			filmtitle.focus();  
			return false;  
		}  
}  

/*Validation for Description of film 
function isdescriptionvalidate()  
{   
		var filmdescription=fms111.filmdescription.value;
		
		var letters = /^[A-Za-z][0-9]+$/;  
		if(filmdescription.match(letters))  
		{  
			document.getElementById("descfilm").innerHTML="";
			return true;  
		}  
		else  
		{  
			document.getElementById("descfilm").innerHTML="* Please Enter the Film Description"; 
			filmdescription.focus();  
			return false;  
		}  
}  */

//Validation for length of film 
function islengthvalid(){
	
	var filmlength=fms.filmlength.value;

    	 if(filmlength>=1 && filmlength<=1000){
    	
    	document.getElementById("lengthfilm").innerHTML="";
		return true;  
    }
    else
    {
    	document.getElementById("lengthfilm").innerHTML="*Length should be between 1 to 3000"; 
    	filmlength.focus();  
		return false; 
    }
    
}

//Validation for replacement cost of film 
function isreplacevalid(){
	
	var filmreplace=fms.replacementcost.value;

    	 if(filmreplace>=1 && filmreplace<=3000){
    	
    	document.getElementById("replacefilm").innerHTML="";
		return true;  
    }
    else
    {
    	document.getElementById("replacefilm").innerHTML="*Length should be between 1 to 3000"; 
    	filmreplace.focus();  
		return false; 
    }
    
    	 
    	 function displayFilm(){
    		//alert("hello");
    		var film_Id=f1.film_Id.value;	
    			//alert(employeeId);
    			//Ajax Code 
    			var xhr = new XMLHttpRequest();
    		    xhr.onreadystatechange = function() {
    		        if (xhr.readyState == 4) {
    		            var data = xhr.responseText;
    		             document.getElementById('displayFilm').innerHTML=data;
    		        }
    		    }
    		    xhr.open('GET', 'DisplayActor?empId='+film_Id, true);
    		  
    		    xhr.send(null);
    			
    		   
    		}
	
}