package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class SaveFilmDetails
 */
public class SaveFilmDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		
		IFilmService loginService=new FilmServiceImpl();
		
		Film film=new Film();
		Category cat=new Category();
		Actor actor=new Actor();
		
		
		film.setTitle(request.getParameter("filmtitle"));
		film.setDescription(request.getParameter("filmdescription"));
		
		film.setLength(Integer.parseInt(request.getParameter("filmlength")));
		
		
		Language lang=new Language(); 
		
		lang.setLanguageId(Integer.parseInt(request.getParameter("originalLanguage")));
		film.setOriginalLanguage(lang);
		
		//Set<Language> languages=new HashSet<>();
		
		List<Language> languages = new ArrayList<>();
		String[] str=request.getParameterValues("originalLanguage");
		for(String str1:str){
			Language lang1=new Language(); 
			lang1.setLanguageId(Integer.parseInt(str1));
			languages.add(lang1);
		}
		film.setLanguages(languages);
		
		
		
	
		 
		
		film.setRatings(Integer.parseInt(request.getParameter("rating")));
		
		Date releaseDate = new Date(request.getParameter("releasedate"));
		film.setReleaseYear(releaseDate);
		
		Date rentalDate = new Date(request.getParameter("rentalduration"));
		film.setRentalDuration(rentalDate);
		
		//film.setRentalDuration(request.getParameter("rentalduration"));
		
		film.setReplacementCost(Double.parseDouble(request.getParameter("replacementcost")));
	
		cat.setCategoryId(Integer.parseInt(request.getParameter("category")));
		film.setCategory(cat);
		//film.setLanguages(request.getParameter(""));
		film.setSpecialFeatures(request.getParameter("specialfeature"));
		
		
		List<Actor> actors = new ArrayList<>();
	
		String[] string=request.getParameterValues("actor");
		for(String str1:str){
			Actor actor1=new Actor(); 
			actor1.setActorId(Integer.parseInt(request.getParameter("actor")));
			actors.add(actor1);
		}
		
		
		film.setActors(actors);
		
		loginService.addFilm(film);
	}

		
		
	}
	
	
	