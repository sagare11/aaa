package com.flp.fms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.LoginUser;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("uname");
		String userPwd=request.getParameter("upwd");
		
		
		
		
		LoginUser loginUser=new LoginUser();
		loginUser.setUserName(userName);
		loginUser.setUserPassword(userPwd);
		
		
		
		
		IFilmService filmService =new FilmServiceImpl();
		
		if(filmService.isValidLogin(loginUser))
			//response.sendRedirect("pages/success.html");
			request.getRequestDispatcher("pages/MenuSelection.html").forward(request, response);
		else
			response.sendRedirect("pages/LoginPage.html");
	}


	}

