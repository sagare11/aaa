package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;

/**
 * Servlet implementation class AddServlet
 */
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FilmServiceImpl filmservice=new FilmServiceImpl();
		
		
		IActorService actorService=new ActorServiceImpl();

		PrintWriter out=response.getWriter();
		
				out.println("<html>");
				out.println("<head>"
				+"<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
				
				out.println("<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>");
				out.println("<script src='//code.jquery.com/jquery-1.10.2.js'></script>");
				out.println(" <script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
						+"<script type='text/javascript' src='script/validateSubmit.js'></script>"
						+ "<script type='text/javascript' src='script/jquery-1.8.3.js'></script>"
		+ "<script type='text/javascript' src='script/jquery-ui-1.9.2.custom.js'></script>"
		+ "<script type='text/javascript' src='script/jquery-ui-1.9.2.custom.min.js'></script>"
		+ "<script type='text/javascript' src='script/dateSelector.js'></script>");
				
				
				
				out.println("");
				
				
				//out.println( "<script type='text/javascript' src='script/validation.js'></script>");
				//out.println( "<script type='text/javascript' src='script/validateSubmit.js'></script>");
			
				
				
				
			
				
				
				
				
				out.println("<title>Film Management System</title>");
				out.println("</head>");
				out.println("<body>");
				//out.println("<form name='fms' method='post' action='SaveFilmDetails'>");
				out.println("<form name='addfilm' onsubmit='return validateForm()' method='post' action='SaveFilmDetails' >");
			
	
				
				

				out.println("<h2><center>Film Registration Form</center></h1>");
				out.print("<table >");
				//out.print("<table>");


				out.println("<tr>"
					+"<td>FilmTitle:</td>"
					//+"<td><input type='text' name='filmtitle' size='20' onmouseout='return  istitlevalidate()'>"
					+"<td><input type='text' name='filmtitle' size='20'>"
					+"<div id='titlefilm' class='errMsg'> </div>"
					+"</td>"
					+"</tr>");
					
					
				out.println("<tr>"
					+"<td>Film Description:</td>"
					+"<td>"
					+"<textarea rows='4' name='filmdescription' cols='25'></textarea>"
					+"<div id='descfms' class='errMsg'> </div> "
					+"</td>"
					+"</tr>");
					
					
					
					out.println("<tr>"
					+"<td>Release Date:</td>"
					+"<td>"
					+"<input type='text' name='releasedate' size='20' id='date23'>"
					+"<div id='relasedate' class='errMsg'> </div> "
					+"</td>"
					+"</tr>");
					
						
					out.println("<tr>"
					+"<td>Rental Duration:</td>"
					+"<td><input type='text' name='rentalduration' size='20' id='date24'>"
					+"<div id='rentaldurationfms' class='errMsg'> </div></td> "
					//+"</td>"
					+"</tr>");
					
					

				/*	out.println("<tr>"
							+"<td>Rental Duration:</td>"
							+"<td><input type='text' name='rentalDuration' id='datepicker2' size='20'>"
							+ "<div id='rentaldurationerr' class='errMsg'></td>"
							+"</tr>");*/
					

					out.println("<tr>"
					+"<td>FilmLength:</td>"
					+"</td>"
					//+"<td><input type='text' name='filmlength' size='20' onmouseout='return  islengthvalid()' >"
					+"<td><input type='text' name='filmlength' size='20'>"
					+"<div id='lengthfilm' class='errMsg'> </div>"
					+"</td>"
					+"<tr>");
					
					out.println("<tr>"
					+"<td>Replacement Cost:</td>"
					+"<td><input type='text' name='replacementcost' size='20'>"
					+"<div id='replacementcostfms' class='errMsg'> </div></td> "
					+"</tr>");
					
					/*out.println("<tr>"
				+"<td>Replacement Cost:</td>"
				+"<td><input type='text' name='replacementcost' size='20'>"
				+"<div id='replacementcosterr' class='errMsg'> </div>"
				+"</td>"*/

					
					
					out.println("<tr>"
						+"<td>Film Rating:</td>"
						+"<td>"
						+"<select name='rating'>"
							+"<option value='1'>1</option>"
							+"<option value='2'>2</option>"
							+"<option value='3'>3</option>"
							+"<option value='4'>4</option>"
							+"<option value='5'>5</option>"
						+"</select>"
						
						+"</td>"
					+"</tr>");
					
					
					
					out.println("<tr>"
					+"<td>Special Features:</td>"
					+"<td>"
						+"<textarea rows='4' name='specialfeature' cols='25'></textarea>"
					+"</td>"
					+"</tr>");

					
					//ACTOR get displayed from Database
					
					List<Actor> actor1 = actorService.getActors();
					
					out.print("<tr><td>Actor</td>"
							+ "<td><select name='actor' multiple=''>");
					for(Actor act:actor1){
						out.print("<option value='"+act.getActor_Id()+"'>"+act.getActor_Id()+" "+act.getFirstName()+" "+act.getLastName()+"</option>");
						
					}
					
				
					out.print("</select></td></tr>");
					
					
                    //Category get displayed using database
					
					
					List<Category> category = filmservice.getcategories();
					
					out.println("<tr><td>Category</td>" + "<td><select name='category'>");
					for(Category cat1:category){
						out.print("<option  value='"+cat1.categoryId+"'>" +cat1.getCategoryId()+""+cat1.getCategoryName()+"</option>");
					}
					out.print("</select></td></tr>");		
					
						
					
					List<Language> languages= filmservice.getLanguages();


					out.print("<tr><td>Original Language :</td>"
							+ "<td><select name='originalLanguage'>");
					
					
					for(Language lang:languages){
						out.print("<option value='"+lang.getLanguageId()+"'>"+lang.getLanguageId()+" "+lang.getLanguageName()+"</option>");
					}
				out.print("</select></td></tr>");
				
				
				
				
				out.print("<tr><td>Other Language :</td>"
						+ "<td><select name='otherLanguage' multiple=''>");
				
					for(Language lang:languages){
						out.print("<option value='"+lang.getLanguageId()+"'>"+lang.getLanguageId()+" "+lang.getLanguageName()+"</option>");
				}
			out.print("</select></td></tr>");			
					
					out.println("<tr>"
						+"<td></td>"
						+"<td><input type='submit' value='Save'>"
						+"<input type='reset' value='Clear'>"
						 +"</td>"
					+"</tr>");

					
		        	out.println("</table>");


				out.println("</form>");


				out.println("</body>");
				out.println("</html>");

				//response.getWriter().append("../AddServlet ").append(request.getContextPath());

				//request.getRequestDispatcher("/AddServlet").forward(request, response);
				//response.sendRedirect("");
}
}