package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;


public class ModifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String filmid=request.getParameter("filmid");
		SimpleDateFormat df=new SimpleDateFormat("dd-MMMM-yyyy");
		IFilmService filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl();
		List<Language> languages=filmService.getLanguages();
		List<Actor>actors=actorService.getActors();
		List<Category>category=filmService.getcategories();
		PrintWriter out=response.getWriter();
		Film tempFilm=new Film();
		tempFilm.setFilm_Id(Integer.parseInt(filmid));
		List<Film> films=filmService.searchFilm(tempFilm);
		Film film=new Film();
		if(!films.isEmpty())
			for(Film f:films)
				film=f;
		out.println("<!DOCTYPE html>"
				+"<html>"
				+"<head>"
				+"<link rel='stylesheet' type='text/css' href='css/mystyles.css'>"
				+"<meta charset='ISO-8859-1'>"
				
				         
				      
				      
				+"<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
				+"<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
				+" <script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
						+ "<script type='text/javascript' src='script/jquery-1.8.3.js'></script>"
		+ "<script type='text/javascript' src='script/jquery-ui-1.9.2.custom.js'></script>"
		+ "<script type='text/javascript' src='script/jquery-ui-1.9.2.custom.min.js'></script>"
		+ "<script type='text/javascript' src='script/dateSelector.js'></script>"
				      
				      
				      +"<script type='text/javascript' src='Script/validate.js'></script>"
			+"	<title>Update Film</title>"
			+"</head>"
			+"	<body>"
			+"	<form name='updatefilm' method='get'action='ModifyServlet2' >"
			+"	<h3>Film Registration Form</h3>"
			+"	<table>"
					+ "<tr><td><input type=text  name=filmid value='"+filmid+"' hidden><td><tr>"
					+"<tr>"
					+"<td>Film Title:</td>"
					+"<td><input type='text' name='filmtitle' size='20' value="+film.getTitle()+" onmouseout='return isValidTitle()'>"
					+"<div id='titleErr' class='errMsg'></div></td></td>"
					+"</tr>"
					
					+"<tr>"
				+"	<td>Description:</td>"
				+"	<td>"
					+"	<textarea rows='4' name='filmdescription' cols='25' >"+film.getDescription()+"</textarea>"
				+"	</td>"
					+"</tr>"
					
				+"	<tr>"
				+"	<td>Release Date:</td>"
					+"<td><input type='text' id='date24' name='releasedate' size='20' value='"+df.format(film.getReleaseYear())+"' >"
				+"	</td>"
				+"	</tr>"
				+"	<tr>"
				+"	<td>Rental Duration:</td>"
					+"<td><input type='text' id ='date23' name='rentaldate' size='20' value='"+df.format(film.getRentalDuration())+"'onmouseout='return isValidRentalDate()'>"
					+"<div id='dateErr' class='errMsg'></div></td>"
					+"</tr>"
					
					+"<tr>"
					+"<td>Film Duration:</td>"
					+"<td><input type='text' name='filmduration' size='20'value="+film.getLength()+" onmouseout='return isValidLength()'>"
					+"<div id='lengthErr' class='errMsg'></div>"
					+"</td>"
					+"</tr>"
					
					+"<tr>"
					+"<td>Replacement Cost:</td>"
					+"<td><input type='text' name='filmreplacementcost' size='20' value="+film.getReplacementCost()+" onmouseout='return isValidCost()'>"
					+"<div id='costErr' class='errMsg'></div></td>"
					+"</tr>"
					
					+"<tr>"
					+"	<td>Rating:</td>"
						+"<td>"
					+"	<select name='rating' >");
						for(int i=1;i<5;i++)
						{	if(i==film.getRatings())
							out.println("<option value='"+i+"'selected>"+i+"</option>");
						else
							out.println("<option value='"+i+"'>"+i+"</option>");
						}
						
							
							
						
					out.println("</select>"
						
					+"	</td>"
				+"	</tr>"
					
					+"<tr>"
				+"	<td>Special Features:</td>"
					+"<td>"
					+"	<textarea rows='4' name='filmspecialfeatures' cols='25'>"+film.getSpecialFeatures()+"</textarea>"
					+"</td>"
				+"	</tr>"
					
					
					+"<tr>"
					+"	<td>Actors:</td>"
						+"<td>"
					+"	<select name='actors'  multiple >");
						for(Actor actor:actors)
						{
							int flag=0;
							for(Actor act:film.getActors())
							{
								if(act.getActor_Id()==actor.getActor_Id())
								{
									out.println("<option value='"+actor.getActor_Id()+"'selected>"+actor.getFirstName()+" "+actor.getLastName() +"</option>");
									flag=1;
									break;
								}
								}
							if(flag!=1)
								out.println("<option value='"+actor.getActor_Id()+"'>"+actor.getFirstName()+" "+actor.getLastName() +"</option>");
								
						}	
						out.println("</select>"
						
					+"	</td>"
						
					
					+"</tr>"
					
			+"<tr>"
					+"	<td>Original Language:</td>"
						+"<td s>"
						+"<select name='language'>");
							for(Language language:languages){
								if(film.getOriginalLanguage().getLanguageId()==language.getLanguageId())
								{out.println("<option value='"+ language.getLanguageId()+"'selected>" + language.getLanguageId() +"</option>");
							}
								else
									out.println("<option value='"+ language.getLanguageId()+"'>" + language.getLanguageId() +"</option>");
							}
									out.println("</select>");
								
							
						
						
						
						out.println("</td>"
					+"</tr>"
					+"<tr>"
					+"	<td>Other Languages:</td>"
						+"<td>"
					+"	<select name='languages' multiple> ");
						for(Language language:languages)
						{
							 int flag=0;
							for(Language lang:film.getLanguages())
								{
								if(lang.getLanguageId()==language.getLanguageId()){
									out.println("<option value='"+ language.getLanguageId()+"'selected>" + language.getLanguageId() +"</option>");
									flag=1;
									break;
								}}
							
							if(flag!=1)
								
									out.println("<option value='"+ language.getLanguageId()+"'>" + language.getLanguageId() +"</option>");
								
							
						}
								out.println("</select>"
							
						
						+"</select>"
						
					+"	</td>"
					+"</tr>"
					
					+"<tr>"
					+"	<td>Category:</td>"
						+"<td >"
						+"<select name='category'>");
								for(Category cat:category){
								if(cat.getCategoryId()==film.getCategory().getCategoryId())
									out.println("<option value='"+ cat.getCategoryId()+"' selected>" + cat.getCategoryName()+"</option>");
								else
									out.println("<option value='"+ cat.getCategoryId()+"'>" + cat.getCategoryName()+"</option>");
								}
					out.println("</select>"
						
						+"</td>"
				+"	</tr>"
					
				+"	<tr>"
						+"<td></td>"
						+"<td><input type='submit' value='Update'>"
						+"<input type='reset' value='Clear'>"
						+" </td>"
					+"</tr>"
					
				+"</table>"


				+"</form>"

			+"	</body>"
			+"	</html>");
					System.out.println(film.getRentalDuration()+"tis is");
				
					
					
		Boolean flag=filmService.modifyFilm(film);
		//if(!flag)
		}
		
	
	
	
	}

