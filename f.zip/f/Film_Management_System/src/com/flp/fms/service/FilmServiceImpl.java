package com.flp.fms.service;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;

public class FilmServiceImpl implements IFilmService{

	private IFilmDao filmDao=new FilmDaoImplForList();
	private IActorDao actorDao=new ActorDaoImplForList();
	
	
	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}

	@Override
	public List<Category> getcategories() {
		
		return filmDao.getCategories();
	}

	
	
	@Override
	public void addFilm(Film film) {
		
		//setting filmId to a random number
	//	film.setFilm_Id(generateFilmId());
		
		filmDao.addFilm(film);
		
	}

	@Override
	public List<Film> getAllFilm() {
		// TODO Auto-generated method stub
		return filmDao.getAllFilms();
	}

	@Override
	public Boolean deleteFilm(int filmid) {
		// TODO Auto-generated method stub
		return filmDao.deleteFilm(filmid);
	}

	@Override
	public List<Film> searchFilm(Film film) {
		// TODO Auto-generated method stub
		return filmDao.searchFilm(film);
	}

	@Override
	public Boolean modifyFilm(Film film) {
		// TODO Auto-generated method stub
		return filmDao.modifyFilm(film);
	}

	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		// TODO Auto-generated method stub
		return filmDao.isValidLogin(loginUser);
	}

	

	
	
	
	
	

	

	
}
