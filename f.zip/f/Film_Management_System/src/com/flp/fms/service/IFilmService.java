package com.flp.fms.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;

public interface IFilmService {

	public List<Language> getLanguages();
	public List<Category> getcategories();
	
	public void addFilm(Film film);
	public List<Film> getAllFilm();
	Boolean deleteFilm(int filmid);

	//public Film searchEmployee(int employeeId);
	
	public List<Film> searchFilm(Film film);
	
	Boolean modifyFilm(Film film);
	public boolean isValidLogin(LoginUser loginUser);
}
