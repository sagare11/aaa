package com.flp.fms.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.LoginUser;



	public interface IFilmDao {

	
	
	
		public List<Language> getLanguages();
		
		public List<Category> getCategories();
	
		public void addFilm(Film film);
	
	    public Map<Integer, Film> removefilm();
		
	    public ArrayList<Film> getAllFilms();
	    
	    public Boolean deleteFilm(int filmid);
	    
	    public List<Film> searchFilm(Film film);
	    
	    Boolean modifyFilm(Film film);
	    
	    public boolean isValidLogin(LoginUser loginUser);

	  
}
