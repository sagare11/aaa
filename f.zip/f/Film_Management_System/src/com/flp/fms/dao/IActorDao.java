package com.flp.fms.dao;

import java.util.List;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Language;


public interface IActorDao {

	public List<Actor> getAllActor();
	
	public List<Language> getAllLanguage();
	
	public List<Actor> getAllActors();
	
	public boolean deleteActor(int actor_Id);
	
}
