package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Language;

public class ActorDaoImplForList implements IActorDao {


	
	
	//To retrive Actor List From Database
	
	@Override
	public List<Actor> getAllActor() {
		ArrayList<Actor> act=new ArrayList<>();
		
		String sql="select * from actors";
		Connection con=getconnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				Actor actor=new Actor();
				
				actor.setActorId(rs.getInt(1));
				actor.setFirstName(rs.getString(2));
				actor.setLastName(rs.getString(3));
				//Adding Actor into List
				act.add(actor);
		
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return act;
	}
	
	
	
	
	
	
	//Database connectivity

	public static Connection getconnection() {

		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/filmmanagementsystem","root","Pass1234");
			
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return connection;
	}


	@Override
	public List<Actor> getAllActors() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Language> getAllLanguage() {
		// TODO Auto-generated method stub
		return null;
	}

@Override
	public boolean deleteActor(int actor_Id) {
		Connection con=getconnection();
		boolean flag=false;
		String sql="delete from actor where actorid=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, actor_Id);
	
			int count=pst.executeUpdate();
			
			if(count>0)
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}




	}


	
	


	

