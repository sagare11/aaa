package com.flp.fms.domain;

public class LoginUser {
	
	//private field
	private String userName;
	private String userPassword;
	
	//No argument constructor
	public LoginUser()
	{
		
	}

	//Constructor with fields
	public LoginUser(String userName, String userPassword) {
		super();
		this.userName = userName;
		this.userPassword = userPassword;
	}

	//Getters and setters
	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	//toString Method
	@Override
	public String toString() {
		return "LoginUser [userName=" + userName + ", userPassword=" + userPassword + "]";
	}
	
	
	
	

}
